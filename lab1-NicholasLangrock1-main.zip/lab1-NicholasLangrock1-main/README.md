# CSCI305-lab1

My name: Nicholas Langrock

About this project: returns hello world from the method getGretting() in main
