# CSCI305-lab3

My name: Nicholas Langrock

About this project: In this project, I implemented heap methods involving heapifying an array into a heap, inserting elements, and removing and rebalancing heaps. I then compared the efficiency of find a kth element from a sorted 2d array using insertion sort (that I borrowed from my previous lab) to finding the kth elemenent from heapifying the 2d array.
the relevent graphs below are the respective time complexity, and using heaps was considerably faster than sorting the array