import java.util.*;

public class TimeSorting{
	public static void main(String[] args) {
		// a lot of things will happen here
		HeapMaxApp heapMax = new HeapMaxApp();
		
		for(int i=100; i<=500;i=i+10){
			int index= (i*i);
		int[][] matrix = heapMax.randomMatrix(i,i);
		 System.out.print(index+","+heapMax.calcTime(matrix, 5,"getKthBiggestNaive"));
    	 System.out.println(","+index+","+heapMax.calcTime(matrix, 5,"getKthBiggest"));
		}
	}

  // you are welcome to add any supporting methods
}
