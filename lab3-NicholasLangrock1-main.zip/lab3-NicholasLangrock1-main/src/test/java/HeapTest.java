
/*
// this is the testing class
// DO NOT MODIFY THIS CLASS AND ITS METHODS
*/
import org.junit.jupiter.api.Test;
import static org.junit.jupiter.api.Assertions.assertArrayEquals;
import static org.junit.jupiter.api.Assertions.assertEquals;
import java.util.Random;
import java.util.ArrayList;

public class HeapTest {
    public int[] randomArray(int size) {
        Random rd = new Random(); // creating Random object
        int[] arr = new int[size];
        for (int i = 0; i < arr.length; i++) {
            arr[i] = rd.nextInt() / 1000000; // storing random integers in an array
        }
        return arr;
    }

    public int randomNumber(int min, int max) {
        return (int) ((Math.random() * (max - min)) + min);
    }

    public String arrayToString(int[] arr) {
        String str = "[";
        for (int i = 0; i < arr.length - 1; i++) {
            str += arr[i] + ", ";
        }
        str += arr[arr.length - 1] + "]";
        return str;
    }

    public String removeLastCharRegex(String s) {
        s = s.replaceAll(".$", "");
        s = s.replaceAll(".$", "");
        return s;
    }

    public String matrixToString(int[][] matrix) {
        String str = "\n[\n";

        for (int i = 0; i < matrix.length; i++) {
            str += "  [";

            for (int j = 0; j < matrix[0].length; j++) {
                str += matrix[i][j] + ", ";
            }
            str = removeLastCharRegex(str);

            str += "],\n";
        }

        str += "]";

        return str;
    }

    public String arrayListToString(ArrayList<Integer> arr) {
        String str = "[";
        for (int i = 0; i < arr.size() - 1; i++) {
            str += arr.get(i) + ", ";
        }
        str += arr.get(arr.size() - 1) + "]";
        return str;
    }

    @Test
    public void buildTest() {
        int[] arr = randomArray(5);
        HeapMaxRight h1 = new HeapMaxRight();
        h1.build(arr);
        HeapMax h2 = new HeapMax();
        h2.build(arr);

        assertArrayEquals(
                h1.getData().toArray(),
                h2.getData().toArray(),
                "\nThis is the test on your build method of your HeapMax class." +
                        "\nThe given array is " + arrayToString(arr) + "\n" +
                        "\nAfter building a max heap based on the array");
    }

    @Test
    public void insertTest() {
        int[] arr = randomArray(5);
        int num = randomNumber(0, 900);
        HeapMaxRight h1 = new HeapMaxRight();
        h1.build(arr);
        h1.insert(num);
        HeapMax h2 = new HeapMax();
        h2.build(arr);
        h2.insert(num);

        assertArrayEquals(
                h1.getData().toArray(),
                h2.getData().toArray(),
                "\nThis is the test on your insert method of your HeapMax class." +
                        "\nThe given heap is build from " + arrayToString(arr) + "\n" +
                        "\nAfter inserting " + num);
    }

    // test removeMaxTest
    @Test
    public void removeMaxTest() {
        int[] arr = randomArray(5);
        HeapMaxRight h1 = new HeapMaxRight();
        h1.build(arr);
        h1.removeMax();
        HeapMax h2 = new HeapMax();
        h2.build(arr);
        h2.removeMax();

        assertArrayEquals(
                h1.getData().toArray(),
                h2.getData().toArray(),
                "\nThis is the test on your removeMax method." +
                        "\nThe given heap is build from " + arrayToString(arr) + "\n" +
                        "\nAfter calling removeMax for one time");
    }

    // test removeMaxTest
    @Test
    public void removeMaxTest2() {
        int[] arr = randomArray(5);
        HeapMaxRight h1 = new HeapMaxRight();
        h1.build(arr);
        h1.removeMax();
        HeapMax h2 = new HeapMax();
        h2.build(arr);
        h2.removeMax();

        assertArrayEquals(
                h1.getData().toArray(),
                h2.getData().toArray(),
                "\nThis is the test on your removeMax method." +
                        "\nThe given heap is build from " + arrayToString(arr) + "\n" +
                        "\nAfter calling removeMax for one time");
    }

    // test HeapMaxAppTest
    @Test
    public void HeapMaxAppTest() {
        // initialize matrix
        int[][] matrix = {  { 96, 41, 15, 13, 12 },
                            { 68, 22, 13, 11, 10 },
                            { 30, 14, 9, 5, 1 } };

        int place = randomNumber(1, 14);

        int expected = HeapMaxAppRight.kthBiggest(matrix, place);
        int actual = HeapMaxApp.getKthBiggest(matrix, place);
        assertEquals(
                expected,
                actual,
                "\nThis is the test on the getKthBiggest method of your HeapMaxApp class." +
                        "\nThe given matrix is build from " + matrixToString(matrix) + "\n" +
                        "\nThe number " + place + " biggest element should be " + expected);
    }

    // test HeapMaxAppTest
    @Test
    public void HeapMaxAppTest2() {
        // initialize matrix
        int[][] matrix = { { 87, 71, 65, 43 }, { 78, 62, 53, 41 }, { 50, 44, 39, 25 } };

        int place = randomNumber(1, 12);

        int expected = HeapMaxAppRight.kthBiggest(matrix, place);
        int actual = HeapMaxApp.getKthBiggest(matrix, place);
        assertEquals(
                expected,
                actual,
                "\nThis is the test on the getKthBiggest method of your HeapMaxApp class." +
                        "\nThe given matrix is build from " + matrixToString(matrix) + "\n" +
                        "\nThe number " + place + " biggest element should be " + expected);

    }
}
