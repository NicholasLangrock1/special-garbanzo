
/*
// this is the testing class
// DO NOT MODIFY THIS CLASS AND ITS METHODS
*/
import org.junit.jupiter.api.Test;
import static org.junit.jupiter.api.Assertions.assertEquals;
import java.util.Random;

public class HashTableTest {
        private Random random = new Random();

        // test insert method
        @Test
        public void insertTest() {
                HashTableCustom<String, Integer> hashTable = new HashTableCustom<>();

                int num = random.nextInt();

                // Test insertion and retrieval
                hashTable.put("apple", num);

                assertEquals(
                                num,
                                hashTable.get("apple"),
                                "\nThis is the test on your insert method of your HashTableCustom class." +
                                                "\nThe given key/value pair to insert is: apple, " + num + "." +
                                                "\nAfter insertion, the retrieved key/value pair is: apple, "
                                                + hashTable.get("apple")
                                                + ".\n");
        }

        // test update method
        @Test
        public void updateTest() {
                HashTableCustom<String, Integer> hashTable = new HashTableCustom<>();

                int num = random.nextInt();

                // Test update
                hashTable.put("apple", num);
                hashTable.put("apple", num + 1);

                assertEquals(
                                num + 1,
                                hashTable.get("apple"),
                                "\nThis is the test on your update method of your HashTableCustom class." +
                                                "\nThe original key/value pair is: apple, " + num + "." +
                                                "\nThe given key/value pair to update is: apple, " + (num + 1) + "." +
                                                "\nAfter update, the retrieved key/value pair is: apple, "
                                                + hashTable.get("apple")
                                                + ".\n");
        }

        // test collision handling
        @Test
        public void collisionTest() {
                HashTableCustom<String, Integer> hashTable = new HashTableCustom<>();

                int num1 = random.nextInt();
                int num2 = random.nextInt();

                // Test collision handling
                hashTable.put("collision1", num1);
                hashTable.put("collision2", num2);

                assertEquals(
                                num1,
                                hashTable.get("collision1"),
                                "\nThis is the test on your collision handling of your HashTableCustom class." +
                                                "\nThe given key/value pair to insert is: collision1, " + num1 + ".\n");
        }

        // test deletion method
        @Test
        public void deletionTest() {
                HashTableCustom<String, Integer> hashTable = new HashTableCustom<>();

                int num = random.nextInt();

                // Test deletion
                hashTable.put("banana", num);
                hashTable.remove("banana");

                assertEquals(
                                null,
                                hashTable.get("banana"),
                                "\nThis is the test on your deletion method of your HashTableCustom class." +
                                                "\nThe given key/value pair to insert is: banana, " + num + "." +
                                                "\nAfter deletion, the retrieved key/value pair is: banana, "
                                                + hashTable.get("banana")
                                                + ".\n");
        }

        // test edge cases - non-existent key
        @Test
        public void edgeCasesTest() {
                HashTableCustom<String, Integer> hashTable = new HashTableCustom<>();

                // Test edge cases
                assertEquals(
                                null,
                                hashTable.get("nonexistent"),
                                "\nThis is the test on your edge cases of your HashTableCustom class." +
                                                "\nThe given key to retrieve is: nonexistent." +
                                                "\nThe retrieved key/value pair is: nonexistent,"
                                                + hashTable.get("nonexistent")
                                                + ".\n");
        }
}
